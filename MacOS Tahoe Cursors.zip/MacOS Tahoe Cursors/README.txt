Thanks for download!
-----------------------------------------------------
How to install:
-----------------------------------------------------

- Download the .rar 
- Extract the .rar
- Open the folder
- Right Click on .inf
- Click Install
- Enjoy!

NOTE: This Cursors pack support up to 128x128 pixels!

-------------------------------------------------------
Please support me:
-------------------------------------------------------

If you want support me: www.paypal.me/JimMata

Buy me a coffee!: ko-fi.com/jimmyxd2